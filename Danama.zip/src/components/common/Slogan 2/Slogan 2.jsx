import './Slogan 2.css';

function Slogan() {
    return (
        <p className="slogan">
            Instant Access to Film Tickets – Anytime, Anywhere!
        </p>
    )
}

export default Slogan;