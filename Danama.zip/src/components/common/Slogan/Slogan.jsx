import './Slogan.css';

function Slogan() {
    return (
        <p className="slogan">
            Your Front-Row Seat Awaits!
        </p>
    )
}

export default Slogan;