import "./SeparateLine.css";

function SeparateLine() {
    return (
        <div className="separate-line"></div>
    );
}

export default SeparateLine;