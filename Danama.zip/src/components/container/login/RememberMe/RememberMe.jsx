import './RememberMe.css';

function RememberMe() {
    return (
        <p className="remember-me">
            <input type="checkbox"/>
            <span>Remember me</span>
        </p>
    )
}

export default RememberMe;