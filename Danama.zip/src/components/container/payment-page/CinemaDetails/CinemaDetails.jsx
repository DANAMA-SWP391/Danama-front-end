function CinemaDetails() {
    return (
        <div className="booking-details__cinema">
            <h3>Cinema:</h3>
            <div>
                <p>CGV Vincom Center</p>
                <p>Level 4 - Vincom Da Nang Shopping Mall, Ngo Quyen Street - An Hai Bac Ward - Son Tra District Da Nang</p>
            </div>
        </div>
    );
}

export default CinemaDetails;