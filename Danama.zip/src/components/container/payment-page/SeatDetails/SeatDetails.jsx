function SeatDetails() {
    return (
        <div className="booking-details__seats">
            <div>
                <h3>Seats:</h3>
                <p>E8</p>
            </div>
            <p>100.000đ</p>
        </div>
    );
}

export default SeatDetails;