function FilmDetails() {
    return (
        <div className="booking-details__film">
            <h3>Film name:</h3>
            <p>Dune Part Two</p>
        </div>
    );
}

export default FilmDetails;