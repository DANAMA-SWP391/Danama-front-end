function TotalDetails() {
    return (
        <div className="booking-details__total">
            <h3>Total:</h3>
            <p>100.000đ</p>
        </div>
    );
}

export default TotalDetails;