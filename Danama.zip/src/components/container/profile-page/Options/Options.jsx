import "./Options.css";

function Options() {
    return (
        <div className="left-container__options">
            <ul>
                <li>User information</li>
                <li>Booking History</li>
                <li>Change Password</li>
                <li>Log out</li>
            </ul>
        </div>
    );
}

export default Options;