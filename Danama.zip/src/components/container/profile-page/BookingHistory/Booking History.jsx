import "./BookingHistory.css";

function BookingHistory() {
    return (
        <table>
            <tbody>
            <tr>
                <th>Booking ID</th>
                <th>Date</th>
                <th>Total</th>
                <th></th>
            </tr>
            </tbody>
            <tbody>
            <tr>
                <td>#01</td>
                <td>23/09/2024</td>
                <td>100.000</td>
                <td>Details</td>
            </tr>
            </tbody>
        </table>
    )
}

export default BookingHistory;